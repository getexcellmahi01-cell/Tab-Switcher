package com.example.tabhopper

import android.content.Context

object Prefs {
    const val TRANSP = "transp"   // 0..MAX_TRANSP (percent)
    const val SIZE = "size"       // dp
    const val COLOR = "color"
    const val STYLE = "style"
    const val X = "x"
    const val Y = "y"
    const val DELAY = "delay"     // ms gap between the two Recents triggers

    // 100% transparent would make the icon impossible to find, so cap it here.
    const val MAX_TRANSP = 95

    private fun sp(c: Context) = c.getSharedPreferences("overlay", Context.MODE_PRIVATE)
    fun getInt(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
    fun putInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
}
