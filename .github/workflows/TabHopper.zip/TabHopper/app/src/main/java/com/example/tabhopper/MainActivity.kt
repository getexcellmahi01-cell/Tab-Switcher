package com.example.tabhopper

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*

class MainActivity : Activity() {

    private val palette = listOf(
        "#F44336", "#E91E63", "#9C27B0", "#673AB7", "#3F51B5", "#2196F3",
        "#03A9F4", "#00BCD4", "#009688", "#4CAF50", "#8BC34A", "#CDDC39",
        "#FFEB3B", "#FFC107", "#FF9800", "#FF5722", "#795548", "#9E9E9E",
        "#607D8B", "#000000", "#FFFFFF", "#FF4081", "#00E676", "#304FFE"
    ).map { Color.parseColor(it) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(32))
        }

        fun title(t: String) = TextView(this).apply {
            text = t; textSize = 16f
            setPadding(0, dp(20), 0, dp(6))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

        fun button(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; setOnClickListener { onClick() }
        }

        fun slider(label: String, key: String, min: Int, max: Int, def: Int, unit: String) {
            val tv = TextView(this)
            val sb = SeekBar(this)
            sb.max = max - min
            val cur = Prefs.getInt(this, key, def).coerceIn(min, max)
            sb.progress = cur - min
            tv.text = "$label: $cur$unit"
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p + min
                    tv.text = "$label: $v$unit"
                    if (fromUser) {
                        Prefs.putInt(this@MainActivity, key, v)
                        OverlayService.refresh(this@MainActivity)
                    }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            root.addView(tv); root.addView(sb)
        }

        // --- Setup ---
        root.addView(title("Setup"))
        root.addView(button("1. Overlay permission dao") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        root.addView(button("2. Accessibility settings kholo") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Tab Hopper on koro", Toast.LENGTH_LONG).show()
        })
        root.addView(button("3. Overlay Start / Stop") {
            when {
                OverlayService.running -> OverlayService.stop(this)
                Settings.canDrawOverlays(this) -> OverlayService.start(this)
                else -> Toast.makeText(this, "Age overlay permission dao", Toast.LENGTH_SHORT).show()
            }
        })

        // --- Look ---
        root.addView(title("Look"))
        slider("Transparency", Prefs.TRANSP, 0, Prefs.MAX_TRANSP, 20, "%")
        slider("Size", Prefs.SIZE, 30, 150, 56, "dp")

        root.addView(title("Color"))
        val grid = GridLayout(this).apply { columnCount = 6 }
        palette.forEach { c ->
            val swatch = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(c)
                    setStroke(dp(1), Color.GRAY)
                }
                layoutParams = GridLayout.LayoutParams().apply {
                    width = dp(44); height = dp(44)
                    setMargins(dp(4), dp(4), dp(4), dp(4))
                }
                setOnClickListener {
                    Prefs.putInt(this@MainActivity, Prefs.COLOR, c)
                    OverlayService.refresh(this@MainActivity)
                }
            }
            grid.addView(swatch)
        }
        root.addView(grid)

        root.addView(title("Icon style"))
        val styles = LinearLayout(this)
        listOf("Circle", "Rounded", "Ring", "Square", "Diamond").forEachIndexed { i, n ->
            styles.addView(button(n) {
                Prefs.putInt(this, Prefs.STYLE, i)
                OverlayService.refresh(this)
            })
        }
        root.addView(HorizontalScrollView(this).apply { addView(styles) })

        root.addView(title("Position"))
        root.addView(button("Position reset (icon haray gele)") {
            Prefs.putInt(this, Prefs.X, 40)
            Prefs.putInt(this, Prefs.Y, 300)
            OverlayService.refresh(this)
        })

        // --- Switch tuning ---
        root.addView(title("Switch tuning"))
        slider("Recents duibar-er gap", Prefs.DELAY, 100, 800, 300, "ms")

        setContentView(ScrollView(this).apply { addView(root) })
    }
}
