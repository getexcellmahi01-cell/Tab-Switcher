package com.example.tabhopper

import android.content.Context
import android.graphics.*
import android.view.View

class OverlayIconView(c: Context) : View(c) {
    var color: Int = Color.parseColor("#2196F3")
        set(v) { field = v; invalidate() }
    var shape: Int = 0   // 0 circle, 1 rounded, 2 ring, 3 square, 4 diamond
        set(v) { field = v; invalidate() }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val glyph = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val pad = w * 0.06f
        val r = RectF(pad, pad, w - pad, h - pad)
        fill.color = color
        line.color = color
        line.strokeWidth = w * 0.10f
        glyph.textSize = w * 0.5f
        glyph.color = Color.WHITE

        when (shape) {
            0 -> canvas.drawOval(r, fill)
            1 -> canvas.drawRoundRect(r, w * 0.22f, w * 0.22f, fill)
            2 -> {
                val half = line.strokeWidth / 2
                r.inset(half, half)
                canvas.drawOval(r, line)
                glyph.color = color
            }
            3 -> canvas.drawRect(r, fill)
            else -> {
                val p = Path().apply {
                    moveTo(w / 2, pad); lineTo(w - pad, h / 2)
                    lineTo(w / 2, h - pad); lineTo(pad, h / 2); close()
                }
                canvas.drawPath(p, fill)
            }
        }
        val y = h / 2 - (glyph.descent() + glyph.ascent()) / 2
        canvas.drawText("\u21C4", w / 2, y, glyph)
    }
}
