package com.example.tabhopper

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class HopAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: HopAccessibilityService? = null
    }

    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() { instance = this }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Recents twice in quick succession = jump to the previously used app. */
    fun hop(gapMs: Long) {
        performGlobalAction(GLOBAL_ACTION_RECENTS)
        handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_RECENTS) }, gapMs)
    }
}
