package com.example.tabhopper

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlin.math.abs

class OverlayService : Service() {

    companion object {
        const val ACTION_REFRESH = "com.example.tabhopper.REFRESH"
        @Volatile var running = false

        fun start(c: Context) =
            ContextCompat.startForegroundService(c, Intent(c, OverlayService::class.java))

        fun stop(c: Context) = c.stopService(Intent(c, OverlayService::class.java))

        fun refresh(c: Context) {
            if (running) c.startService(
                Intent(c, OverlayService::class.java).setAction(ACTION_REFRESH)
            )
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var icon: OverlayIconView
    private lateinit var lp: WindowManager.LayoutParams

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        startAsForeground()

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        icon = OverlayIconView(this)

        lp = WindowManager.LayoutParams(
            0, 0,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        applyPrefs()
        icon.setOnTouchListener(touchListener())
        wm.addView(icon, lp)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_REFRESH) applyPrefs()
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        if (::icon.isInitialized) runCatching { wm.removeView(icon) }
        super.onDestroy()
    }

    private fun applyPrefs() {
        val d = resources.displayMetrics.density
        val sizePx = (Prefs.getInt(this, Prefs.SIZE, 56) * d).toInt()
        val transp = Prefs.getInt(this, Prefs.TRANSP, 20).coerceIn(0, Prefs.MAX_TRANSP)
        lp.width = sizePx
        lp.height = sizePx
        lp.x = Prefs.getInt(this, Prefs.X, 40)
        lp.y = Prefs.getInt(this, Prefs.Y, 300)
        icon.alpha = (100 - transp) / 100f
        icon.color = Prefs.getInt(this, Prefs.COLOR, Color.parseColor("#2196F3"))
        icon.shape = Prefs.getInt(this, Prefs.STYLE, 0)
        if (icon.isAttachedToWindow) wm.updateViewLayout(icon, lp)
    }

    private fun touchListener() = object : View.OnTouchListener {
        private val slop = ViewConfiguration.get(this@OverlayService).scaledTouchSlop
        private var startX = 0; private var startY = 0
        private var downX = 0f; private var downY = 0f
        private var moved = false

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    downX = e.rawX; downY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt()
                    val dy = (e.rawY - downY).toInt()
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        lp.x = startX + dx
                        lp.y = startY + dy
                        wm.updateViewLayout(icon, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        Prefs.putInt(this@OverlayService, Prefs.X, lp.x)
                        Prefs.putInt(this@OverlayService, Prefs.Y, lp.y)
                    } else hop()
                }
            }
            return true
        }
    }

    private fun hop() {
        val svc = HopAccessibilityService.instance
        if (svc == null) {
            Toast.makeText(this, "Accessibility service on koro", Toast.LENGTH_SHORT).show()
            return
        }
        svc.hop(Prefs.getInt(this, Prefs.DELAY, 300).toLong())
    }

    private fun startAsForeground() {
        val chId = "overlay"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(chId, "Overlay", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, chId)
            .setSmallIcon(android.R.drawable.ic_menu_rotate)
            .setContentTitle("Tab Hopper cholche")
            .setContentText("Settings khulte tap koro")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this, 1, n,
            if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        )
    }
}
